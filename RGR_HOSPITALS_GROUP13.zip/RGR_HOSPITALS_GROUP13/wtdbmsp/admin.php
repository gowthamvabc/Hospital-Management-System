<?php
//This script will handle login
session_start();

// check if the user is already logged in

require_once "configure.php";

$username1 = $password1 = "";
$err = "";

// if request method is post
if ($_SERVER['REQUEST_METHOD'] == "POST"){
    if(empty(trim($_POST['username'])) || empty(trim($_POST['password'])))
    {
        $err = "Please enter username + password";
    }
    else{
        $username1 = trim($_POST['username']);
        $password1 = trim($_POST['password']);
    }


if(empty($err))
{
    $sql = "SELECT id, username, password FROM admin WHERE username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $param_username1);
    $param_username1 = $username1;


    // Try to execute this statement
    if(mysqli_stmt_execute($stmt)){
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt) == 1)
                {
                    mysqli_stmt_bind_result($stmt, $id1, $username1, $hashed_password1);
                    if(mysqli_stmt_fetch($stmt))
                    {
                        if(password_verify($password1, $hashed_password1))
                        {
                            // this means the password is corrct. Allow user to login
                            session_start();
                            $_SESSION["username"] = $username1;
                            $_SESSION["id"] = $id1;
                            $_SESSION["loggedin"] = true;

                            //Redirect user to welcome page
                            header("location: adminwel.php");

                        }
                    }

                }

    }
}


}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin details</title>
    <link rel="stylesheet" href="admin.css">
    <style>
       h1{ 
        background-color: white;
    font-size: 45px;
    color: black;
    font-family: Arial, Helvetica, sans-serif;
    text-align: center;
    
}

.patient_align{
    background-color: whitesmoke;
    font-size: 25px;
    position:absolute;
    font-family: Arial, Helvetica, sans-serif;
    color: black;
    text-align: center;
    width: 290px;
    margin-left: 500px;
    margin-top: 15px;
}
    body{
    background-image: url("hospital5.jpg");
    background-color: #cccccc;
  height: 500px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;

}
     

    

        </style>
</head>
<body>
   <br><br>    <br><br>   <br><br>   <br><br> <h1> Login as Admin </h1>
    <form action="" method="post">
    <div class="patient_align">
        
        <input type="text" id="phone_num" name="username" placeholder="Enter username*" required><br><br>
        <input type="password" id="password" name="password" placeholder="Password*" required><br><br>
        
        
        
        <button id ="click" type="submit" value="login"> Login </button><br><br>

        </form>
    
    
        
        
        
        
        
</div>
</body>
</html>