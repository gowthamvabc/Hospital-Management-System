<?php
$insert = false;
if(isset($_POST['name'])){
    // Set connection variables
    $server = "localhost";
    $username = "root";
    $password = "passwordchanged12";

    // Create a database connection
    $con = mysqli_connect($server, $username, $password);

    // Check for connection success
    if(!$con){
        die("connection to this database failed due to" . mysqli_connect_error());
    }
    // echo "Success connecting to the db";

    // Collect post variables
    $name = $_POST['name'];
    $gender = $_POST['doctors'];
    $age = $_POST['doctor_fee'];
    $email = $_POST['p_time'];
    
    $sql = "INSERT INTO wtdbmsp.patient_appoint (name, doctors, doctor_fee, p_time) VALUES ('$name','$gender', '$age', '$email');";
    // echo $sql;

    // Execute the query
    if($con->query($sql) == true){
        // echo "Successfully inserted";

        // Flag for successful insertion
        $insert = true;
        header("location: appoint_submit.php");
        

    }
    else{
        echo "ERROR: $sql <br> $con->error";
    }

    // Close the database connection
    $con->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Appointment</title>
<link rel="stylesheet" href="appoint.css">
</head>
<body>
    
    <h1> Appointment </h1>
    <div class="patient_align">
    <form action="" method="post">
    <label for="name">Enter name:</label>
    <input type="text" id="name" name="name" placeholder="Enter name of patient* " required><br><br>
    <label for="doctor_n">Choose a Doctor:</label>
  <select name="doctors" id="doctor_n">
    <option value="SHARATH">DR. SHARATH[CARDIOLOGY]</option>
    <option value="SOHITH">DR. SOHITH[NEUROLOGY]</option>
    <option value="GOWTHAM">DR. GOWTHAM[ONCOLOGY]</option>
    <option value="KARTHIK">DR. KARTHIK[NUTRITION]</option>
  </select>
  <br><br>
  <label for="doctor_fee">Doctor Fee:</label>
  <input type="text" id="doctor_fee" name="doctor_fee" value="500" readonly><br><br>

  <label for="date">Choose preferred Date and Time:</label>
  <input type="datetime-local" id="date" name="p_time" required><br><br>
  <button type="submit" name ="submit">Submit</button>
</div>

</body>
</html>







