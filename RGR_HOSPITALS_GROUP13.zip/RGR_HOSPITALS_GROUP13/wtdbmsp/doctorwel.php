
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Details</title>
    <link rel="stylesheet" href="adminwel.css">
</head>
<body>
    <h1>Welcome Doctor</h1>
    <br>
    <h2> Appointment Details</h2>
    <?php
$servername = "localhost";
$username = "root";
$password = "passwordchanged12";
$dbname = "wtdbmsp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name, doctors, doctor_fee, p_time FROM patient_appoint";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    ?>
    <table>
        <tr>
        <th> name </th>
        <th> Doctor name</th>
        <th> Doctor fee </th>
        <th>Date & Time </th>
    </tr>
    



    <?php
    while($row = $result->fetch_assoc()) {
        echo " <tr><td> ". $row["name"]. " </td><td> ". $row["doctors"]. "</td><td> " . $row["doctor_fee"]."</td><td>". $row["p_time"] ."</td></tr>";
    }
} else {
    echo "0 results";
}

$conn->close();
?>
</body>
</html>