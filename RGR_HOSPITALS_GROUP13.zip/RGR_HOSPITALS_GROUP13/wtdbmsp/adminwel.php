<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment details</title>
    <link rel="stylesheet" href="adminwel.css">
</head>
<body>
    <h1>Appointment Details</h1>
    <?php
$servername = "localhost";
$username = "root";
$password = "passwordchanged12";
$dbname = "wtdbmsp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name, doctors, doctor_fee, p_time FROM patient_appoint";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    ?>
    <table>
        <tr>
        <th> Name </th>
        <th> Doctor name</th>
        <th> Doctor fee </th>
        <th>Date & Time </th>
    </tr>
    



    <?php
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo " <tr><td> ". $row["name"]. " </td><td> ". $row["doctors"]. "</td><td> " . $row["doctor_fee"]."</td><td>". $row["p_time"] ."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>
</body>
</html>